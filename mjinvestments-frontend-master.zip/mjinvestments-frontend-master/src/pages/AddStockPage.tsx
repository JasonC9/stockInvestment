import { Grid } from "@material-ui/core";
import AddForm from "../components/AddForm";
import AddStock from "../components/AddStock";
import "../components/Login.css";

export default function AddStockPage() {

    return (
        
        <div>
            <AddStock />
        </div>
       

    )
}