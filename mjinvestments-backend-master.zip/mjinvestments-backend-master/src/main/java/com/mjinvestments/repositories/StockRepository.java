package com.mjinvestments.repositories;
import com.mjinvestments.POJOClasses.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface StockRepository extends JpaRepository<Stock, Integer>
{
    public Stock findById(int stockName);
}
